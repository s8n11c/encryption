package Monoalphabetic;

public class pair {
	
		// encryption pairing 
		/*
		 * left is the cipher 
		 * right is the key 
		 */
		private String left;
		private String right;
		
		public pair(String left, String right) {
			// TODO Auto-generated constructor stub
			this.left=left;
			this.right=right;
		}

		
		public String get_left(){
			return this.left;
		}
		
		public String get_right(){
			return this.right;
		}
		
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
